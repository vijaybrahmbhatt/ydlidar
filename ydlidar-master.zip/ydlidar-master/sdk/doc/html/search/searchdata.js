var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstwy~",
  1: "cdeflmnpsty",
  2: "s",
  3: "acdefgilorswy~",
  4: "_acdefhimprstw",
  5: "bfps",
  6: "dmy",
  7: "y"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

